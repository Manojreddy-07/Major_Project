# Liver_Cirrhosis_Status_Prediction
Here i am predicting the status of Liver Cirrhosis
